package kr.co.mlec.homework.homework08;

public interface Game {
	public abstract int startGame(int you);
}
