package kr.co.mlec.homework.homework10;

public class BoardMain {

	public static void main(String[] args) {
		Board b = new Board();
		b.start();
	}

}
