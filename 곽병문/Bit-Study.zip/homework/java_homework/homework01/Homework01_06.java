package kr.co.mlec.homework.homework01;

public class Homework01_06 {

	public static void main(String[] args) {
		
		int an = ('z'-'a'+1) + ('Z'-'A'+1);
		System.out.println(an);

	}

}
