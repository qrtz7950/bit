package kr.co.mlec.homework.homework01;

public class Homework01_03 {

	public static void main(String[] args) {
		
		final double PI = 3.141592;
		int r = 10;
		System.out.printf("%.4f", PI*r*r);

	}

}
