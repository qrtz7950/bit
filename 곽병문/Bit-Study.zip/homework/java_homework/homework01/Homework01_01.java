package kr.co.mlec.homework.homework01;

/*
 * ���ĺ� �ƽ�Ű�ڵ��  ���
 */

public class Homework01_01 {

	public static void main(String[] args) {
		
		System.out.println('A'+0);
		System.out.println('E'+0);
		System.out.println('I'+0);
		System.out.println('O'+0);
		System.out.println('U'+0);
		
	}

}
