/*
 	2018.7.3
*/

package kr.co.mlec.day01;

//	import java.util.Scanner;	// �Է��Ϸ��� ����Ʈ

public class HelloMain {

	public static void main(String args[]) {
		
		System.out.println("Hello World");
		System.out.println("���");
		
//		Scanner scan = new Scanner(System.in);
//		String input = scan.next();
//		System.out.println(input+" ����");
//		
//		scan.close();
	}
	
}
