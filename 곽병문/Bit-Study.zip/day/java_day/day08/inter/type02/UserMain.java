package kr.co.mlec.day08.inter.type02;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
