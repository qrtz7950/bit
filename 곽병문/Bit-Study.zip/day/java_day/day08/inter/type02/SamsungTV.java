package kr.co.mlec.day08.inter.type02;

public class SamsungTV implements TV {

}
