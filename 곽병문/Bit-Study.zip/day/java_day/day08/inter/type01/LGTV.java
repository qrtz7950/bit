package kr.co.mlec.day08.inter.type01;

public class LGTV {
	
	boolean power;
	
	public void powerOn() {
		System.out.println("Power ON()...");
	}
	
	public void powerOff() {
		System.out.println("Power Off()...");
	}
	
	public void channelUp() {
		System.out.println("channel UP()...");
	}
	
	public void channelDown() {
		System.out.println("channel DOWN()...");
	}
	
	public void volumeUp() {
		System.out.println("volume UP()...");
	}
	
	public void volumeDown() {
		System.out.println("volume DOWN()...");
	}
}
