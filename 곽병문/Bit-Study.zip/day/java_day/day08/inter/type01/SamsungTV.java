package kr.co.mlec.day08.inter.type01;

public class SamsungTV {
	
	boolean power;
	
	public void turnOn() {
		System.out.println("���� ON()");
	}
	
	public void turnOff() {
		System.out.println("���� Off()");
	}
	
	public void channelUp() {
		System.out.println("ä�� UP()");
	}
	
	public void channelDown() {
		System.out.println("ä�� DOWN()");
	}
	
	public void soundUp() {
		System.out.println("���� UP()");
	}
	
	public void soundDown() {
		System.out.println("���� DOWN()");
	}
	
}
