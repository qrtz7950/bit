package kr.co.mlec.day08.cast;

public class Parent {
    private String name = "�ƹ���";
    private int age = 40;

    public void info(){
    	System.out.println(name + ", ���� : " + age);
    }

}
