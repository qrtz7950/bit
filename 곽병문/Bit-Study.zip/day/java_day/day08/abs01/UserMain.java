package kr.co.mlec.day08.abs01;

public class UserMain {

	public static void main(String[] args) {
		
		Menu m = new Menu();
		m.process();

	}

}
