package kr.co.mlec.day08.abs01;

abstract class Printer {
	
	private String productName;
	public abstract void print();
}
