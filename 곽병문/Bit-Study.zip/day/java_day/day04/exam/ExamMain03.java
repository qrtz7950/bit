package kr.co.mlec.day04.exam;

public class ExamMain03 {

	public static void main(String[] args) {
		
		
		
	}
	
}
