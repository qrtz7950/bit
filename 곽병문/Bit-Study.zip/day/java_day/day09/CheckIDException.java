package kr.co.mlec.day09;

public class CheckIDException extends Exception{

	public CheckIDException() {
		super();
	}
	CheckIDException(String str){
		super(str);
	}

}
