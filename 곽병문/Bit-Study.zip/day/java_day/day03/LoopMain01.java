package kr.co.mlec.day03;

public class LoopMain01 {

	public static void main(String[] args) {
		
		int i=1;
		while(i <= 5) {
			System.out.println("Hello");
			i++;
		}
		System.out.println("----------------------------");
		
		for(i=1; i<=5; i++) {
			System.out.println("Hello");
		}
		
	}

}
