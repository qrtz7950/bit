package kr.co.mlec.day03.exam;

public class ExamMain01 {

	public static void main(String[] args) {
		
		for(int i=5; i>0; i--) {
			System.out.print(i);
			System.out.println();
		}
		
	}

}
