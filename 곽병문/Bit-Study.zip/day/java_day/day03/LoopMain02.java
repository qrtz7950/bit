package kr.co.mlec.day03;

/*
 	*****
 */

public class LoopMain02 {

	public static void main(String[] args) {
		
		for(int i=0; i<5; i++) {
			System.out.print('*');
		}
		
		System.out.println();
		
		for(int i=0; i<5; i++) {
			System.out.print(5-i);
		}
		
	}

}
