package kr.co.mlec.board.ui;

public interface IBoardUI {

	void execute() throws Exception;
}
